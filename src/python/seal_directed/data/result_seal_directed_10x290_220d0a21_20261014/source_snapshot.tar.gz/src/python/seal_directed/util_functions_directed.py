from __future__ import print_function
import numpy as np
import random
from tqdm import tqdm
import os, sys, pdb, math, time
import networkx as nx
import argparse
import scipy.io as sio
import scipy.sparse as ssp
from sklearn import metrics
import warnings
warnings.simplefilter('ignore', ssp.SparseEfficiencyWarning)
cur_dir = os.path.dirname(os.path.realpath(__file__))
python_dir = os.path.dirname(cur_dir)
sys.path.append('%s/pytorch_DGCNN' % python_dir)
from util import GNNGraph
import multiprocessing as mp
from itertools import islice


def remove_self_loops(A):
    A = ssp.csr_matrix(A)
    A = A.copy()
    A.setdiag(0)
    A.eliminate_zeros()
    return A


def binarize_adjacency(A):
    A = remove_self_loops(A)
    A.data = np.ones_like(A.data)
    return A


def weak_projection(A):
    A = binarize_adjacency(A)
    A_weak = A + A.transpose()
    A_weak.data = np.ones_like(A_weak.data)
    return remove_self_loops(A_weak)


def role_vector_to_code(role, n):
    """Encode node roles for directed negative sampling.

    Codes:
      0 unknown
      1 consumer only
      2 resource only
      3 consumer-resource
    """
    code = np.zeros(n, dtype=np.int8)
    if role is None:
        return code

    role_arr = np.asarray(role).reshape(-1)
    upto = min(n, role_arr.size)
    for idx in range(upto):
        value = role_arr[idx]
        if isinstance(value, np.ndarray):
            value = value.reshape(-1)[0] if value.size else ''
        value = str(value).strip().lower()
        if value == 'consumer':
            code[idx] = 1
        elif value == 'resource':
            code[idx] = 2
        elif value in ('consumer-resource', 'resource-consumer', 'both'):
            code[idx] = 3
    return code


def directed_role_mask(role_code):
    role_code = np.asarray(role_code)
    source_can_be_resource = (role_code == 2) | (role_code == 3)
    target_can_be_consumer = (role_code == 1) | (role_code == 3)
    return source_can_be_resource[:, None] & target_can_be_consumer[None, :]


def enumerate_negative_links_directed(net, role_code=None, use_role_filter=False):
    net = binarize_adjacency(net)
    n = net.shape[0]
    occupied = net.toarray().astype(bool)
    candidate = ~occupied
    np.fill_diagonal(candidate, False)

    if use_role_filter and role_code is not None and np.any(role_code):
        candidate &= directed_role_mask(role_code)

    row, col = np.where(candidate)
    return row.astype(np.int64), col.astype(np.int64)


def sample_neg(net, test_ratio=0.1, train_pos=None, test_pos=None, max_train_num=None,
               all_unknown_as_negative=False, role_code=None, use_role_filter=False,
               return_metadata=False):
    net = binarize_adjacency(net)
    row, col, _ = ssp.find(net)
    keep = row != col
    row, col = row[keep], col[keep]

    # sample positive links if not specified
    if train_pos is None and test_pos is None:
        perm = random.sample(range(len(row)), len(row))
        row, col = row[perm], col[perm]
        split = int(math.ceil(len(row) * (1 - test_ratio)))
        if len(row) > 1 and test_ratio > 0:
            split = min(max(split, 1), len(row) - 1)
        train_pos = (row[:split], col[:split])
        test_pos = (row[split:], col[split:])
    # if max_train_num is set, randomly sample train links
    if max_train_num is not None and train_pos is not None:
        perm = np.random.permutation(len(train_pos[0]))[:max_train_num]
        train_pos = (train_pos[0][perm], train_pos[1][perm])
    # sample negative links for train/test
    train_num = len(train_pos[0]) if train_pos else 0
    test_num = len(test_pos[0]) if test_pos else 0
    need_num = train_num + test_num
    print('sampling directed negative links for train and test')

    neg_row, neg_col = enumerate_negative_links_directed(
        net, role_code=role_code, use_role_filter=use_role_filter
    )
    constrained_pool_size = len(neg_row)
    fallback_used = False
    if len(neg_row) < need_num and use_role_filter:
        print('role-constrained negative pool too small; falling back to all directed unknown links')
        neg_row, neg_col = enumerate_negative_links_directed(
            net, role_code=role_code, use_role_filter=False
        )
        fallback_used = True

    if not all_unknown_as_negative:
        if len(neg_row) < need_num:
            raise ValueError(
                'Not enough directed negative links: need {}, have {}'.format(
                    need_num, len(neg_row)
                )
            )
        perm = np.random.permutation(len(neg_row))[:need_num]
        neg_row, neg_col = neg_row[perm], neg_col[perm]
        train_neg = (neg_row[:train_num], neg_col[:train_num])
        test_neg = (neg_row[train_num:], neg_col[train_num:])
    else:
        if len(neg_row) < train_num:
            raise ValueError(
                'Not enough directed negative links: need train {}, have {}'.format(
                    train_num, len(neg_row)
                )
            )
        train_perm = np.random.permutation(len(neg_row))[:train_num]
        train_neg = (neg_row[train_perm], neg_col[train_perm])
        test_neg = (neg_row, neg_col)
    metadata = {
        'negative_sampling': 'uniform_without_replacement',
        'negative_positive_ratio': 1,
        'role_filter_requested': bool(use_role_filter),
        'role_constrained_pool_size': int(constrained_pool_size),
        'selected_pool_size': int(len(neg_row)),
        'required_negative_count': int(need_num),
        'role_pool_fallback_used': bool(fallback_used),
        'fallback_policy': 'replace_with_all_directed_nonlinks',
        'train_negative_count': int(len(train_neg[0])),
        'test_negative_count': int(len(test_neg[0])),
    }
    result = (train_pos, train_neg, test_pos, test_neg)
    if return_metadata:
        return result + (metadata,)
    return result


def links2subgraphs(A, train_pos, train_neg, test_pos, test_neg, h=1,
                    max_nodes_per_hop=None, node_information=None, no_parallel=False,
                    num_workers=None):
    # automatically select h from {1, 2}
    if h == 'auto':
        # split train into val_train and val_test
        _, _, val_test_pos, val_test_neg = sample_neg(A, 0.1)
        val_A = A.copy()
        val_A[val_test_pos[0], val_test_pos[1]] = 0
        val_auc_CN = CN(val_A, val_test_pos, val_test_neg)
        val_auc_AA = AA(val_A, val_test_pos, val_test_neg)
        print('\033[91mValidation AUC of AA is {}, CN is {}\033[0m'.format(
            val_auc_AA, val_auc_CN))
        if val_auc_AA >= val_auc_CN:
            h = 2
            print('\033[91mChoose h=2\033[0m')
        else:
            h = 1
            print('\033[91mChoose h=1\033[0m')

    # extract enclosing subgraphs
    max_n_label = {'value': 0}
    workers = 1 if no_parallel else int(num_workers or 1)
    pool = None
    if workers > 1:
        pool = mp.get_context('spawn').Pool(processes=workers)

    def helper(A, links, g_label):
        g_list = []
        if workers <= 1:
            for i, j in tqdm(
                zip(links[0], links[1]),
                total=len(links[0]),
                disable=not sys.stderr.isatty(),
            ):
                g, n_labels, n_features = subgraph_extraction_labeling(
                    (i, j), A, h, max_nodes_per_hop, node_information
                )
                max_n_label['value'] = max(max(n_labels), max_n_label['value'])
                g_list.append(GNNGraph(g, g_label, n_labels, n_features))
            return g_list
        else:
            # the parallel extraction code
            start = time.time()
            work_items = [
                ((i, j), A, h, max_nodes_per_hop, node_information)
                for i, j in zip(links[0], links[1])
            ]
            results = list(tqdm(
                pool.imap(parallel_worker, work_items),
                total=len(work_items),
                disable=not sys.stderr.isatty(),
            ))
            g_list = [GNNGraph(g, g_label, n_labels, n_features) for g, n_labels, n_features in results]
            if results:
                max_n_label['value'] = max(
                    max([max(n_labels) for _, n_labels, _ in results]), max_n_label['value']
                )
            end = time.time()
            print("Time eplased for subgraph extraction: {}s".format(end-start))
            return g_list

    print('Enclosing subgraph extraction begins...')
    train_graphs, test_graphs = None, None
    try:
        if train_pos and train_neg:
            train_graphs = helper(A, train_pos, 1) + helper(A, train_neg, 0)
        if test_pos and test_neg:
            test_graphs = helper(A, test_pos, 1) + helper(A, test_neg, 0)
        elif test_pos:
            test_graphs = helper(A, test_pos, 1)
    finally:
        if pool is not None:
            pool.close()
            pool.join()
    return train_graphs, test_graphs, max_n_label['value']

def parallel_worker(x):
    return subgraph_extraction_labeling(*x)

def subgraph_extraction_labeling(ind, A, h=1, max_nodes_per_hop=None,
                                 node_information=None):
    # extract the h-hop enclosing subgraph around link 'ind'
    dist = 0
    nodes = set([ind[0], ind[1]])
    visited = set([ind[0], ind[1]])
    fringe = set([ind[0], ind[1]])
    nodes_dist = [0, 0]
    for dist in range(1, h+1):
        fringe = neighbors(fringe, A)
        fringe = fringe - visited
        visited = visited.union(fringe)
        if max_nodes_per_hop is not None:
            if max_nodes_per_hop < len(fringe):
                fringe = random.sample(fringe, max_nodes_per_hop)
        if len(fringe) == 0:
            break
        nodes = nodes.union(fringe)
        nodes_dist += [dist] * len(fringe)
    # move target nodes to top
    nodes.remove(ind[0])
    nodes.remove(ind[1])
    nodes = [ind[0], ind[1]] + list(nodes)
    subgraph = A[nodes, :][:, nodes].tolil()
    subgraph[0, 1] = 0
    subgraph = subgraph.tocsr()

    # apply node-labeling
    labels = directed_node_label(subgraph)

    # get node features
    features = None
    if node_information is not None:
        features = node_information[nodes]

    # construct nx graph
    # The current DGCNN backend is undirected, so we train on the weak
    # projection while preserving link order through distinct source/target
    # labels. A reverse target->source edge is preserved as valid context.
    graph_matrix = weak_projection(subgraph)
    try:
        g = nx.from_scipy_sparse_array(graph_matrix)
    except AttributeError:
        g = nx.from_scipy_sparse_matrix(graph_matrix)
    return g, labels.tolist(), features


def neighbors(fringe, A):
    # find all weak directed 1-hop neighbors of nodes in fringe from A
    res = set()
    for node in fringe:
        incoming, _, _ = ssp.find(A[:, node])
        _, outgoing, _ = ssp.find(A[node, :])
        res = res.union(set(incoming)).union(set(outgoing))
    return res


def directed_node_label(subgraph):
    labels = node_label(weak_projection(subgraph))
    labels = labels.copy()
    non_target = labels[2:]
    finite_non_target = non_target > 0
    non_target[finite_non_target] += 2
    labels[2:] = non_target
    labels[0] = 1
    labels[1] = 2
    return labels


def node_label(subgraph):
    # an implementation of the proposed double-radius node labeling (DRNL)
    K = subgraph.shape[0]
    subgraph_wo0 = subgraph[1:, 1:]
    subgraph_wo1 = subgraph[[0]+list(range(2, K)), :][:, [0]+list(range(2, K))]
    dist_to_0 = ssp.csgraph.shortest_path(subgraph_wo0, directed=False, unweighted=True)
    dist_to_0 = dist_to_0[1:, 0]
    dist_to_1 = ssp.csgraph.shortest_path(subgraph_wo1, directed=False, unweighted=True)
    dist_to_1 = dist_to_1[1:, 0]
    labels = np.zeros(dist_to_0.shape, dtype=np.int64)
    finite_dist = np.isfinite(dist_to_0) & np.isfinite(dist_to_1)
    if np.any(finite_dist):
        dist0 = dist_to_0[finite_dist].astype(np.int64)
        dist1 = dist_to_1[finite_dist].astype(np.int64)
        d = dist0 + dist1
        d_over_2, d_mod_2 = np.divmod(d, 2)
        labels[finite_dist] = 1 + np.minimum(dist0, dist1) + d_over_2 * (d_over_2 + d_mod_2 - 1)
    labels = np.concatenate((np.array([1, 1]), labels))
    return labels


def generate_node2vec_embeddings(A, emd_size=128, negative_injection=False, train_neg=None):
    from gensim.models import Word2Vec

    node2vec_path = '%s/software/node2vec/src' % python_dir
    if node2vec_path not in sys.path:
        sys.path.append(node2vec_path)
    import node2vec

    if negative_injection:
        row, col = train_neg
        A = A.copy()
        A[row, col] = 1  # inject negative train
    try:
        nx_G = nx.from_scipy_sparse_array(A, create_using=nx.DiGraph())
    except AttributeError:
        nx_G = nx.from_scipy_sparse_matrix(A, create_using=nx.DiGraph())
    G = node2vec.Graph(nx_G, is_directed=True, p=1, q=1)
    G.preprocess_transition_probs()
    walks = G.simulate_walks(num_walks=10, walk_length=80)
    walks = [list(map(str, walk)) for walk in walks]
    model = Word2Vec(walks, size=emd_size, window=10, min_count=0, sg=1,
            workers=8, iter=1)
    wv = model.wv
    embeddings = np.zeros([A.shape[0], emd_size], dtype='float32')
    sum_embeddings = 0
    empty_list = []
    for i in range(A.shape[0]):
        if str(i) in wv:
            embeddings[i] = wv.word_vec(str(i))
            sum_embeddings += embeddings[i]
        else:
            empty_list.append(i)
    mean_embedding = sum_embeddings / (A.shape[0] - len(empty_list))
    embeddings[empty_list] = mean_embedding
    return embeddings


def AA(A, test_pos, test_neg):
    # Adamic-Adar score
    A = weak_projection(A)
    A_ = A / np.log(A.sum(axis=1))
    A_[np.isnan(A_)] = 0
    A_[np.isinf(A_)] = 0
    sim = A.dot(A_)
    return CalcAUC(sim, test_pos, test_neg)


def CN(A, test_pos, test_neg):
    # Common Neighbor score
    A = weak_projection(A)
    sim = A.dot(A)
    return CalcAUC(sim, test_pos, test_neg)


def CalcAUC(sim, test_pos, test_neg):
    pos_scores = np.asarray(sim[test_pos[0], test_pos[1]]).squeeze()
    neg_scores = np.asarray(sim[test_neg[0], test_neg[1]]).squeeze()
    scores = np.concatenate([pos_scores, neg_scores])
    labels = np.hstack([np.ones(len(pos_scores)), np.zeros(len(neg_scores))])
    fpr, tpr, _ = metrics.roc_curve(labels, scores, pos_label=1)
    auc = metrics.auc(fpr, tpr)
    return auc
